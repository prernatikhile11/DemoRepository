package com.icici.bdr.mis.report.web.portlet;

public class documentstore {

	private String solId;
	private String sectionName;
	private String documentType;
	public String getSolId() {
		return solId;
	}
	public void setSolId(String solId) {
		this.solId = solId;
	}
	public String getSectionName() {
		return sectionName;
	}
	public void setSectionName(String sectionName) {
		this.sectionName = sectionName;
	}
	public String getDocumentType() {
		return documentType;
	}
	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}
	public documentstore(String solId, String sectionName, String documentType) {
		super();
		this.solId = solId;
		this.sectionName = sectionName;
		this.documentType = documentType;
	}
	public documentstore() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
}
