package com.icici.bdr.mis.report.web.portlet;

import com.icici.bdr.mis.report.web.constants.BdrMisReportWebPortletKeys;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCResourceCommand;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.kernel.util.WebKeys;

import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.portlet.PortletException;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import org.osgi.service.component.annotations.Component;

import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

@Component(
    property = {
        "javax.portlet.name=" + BdrMisReportWebPortletKeys.BDRMISREPORTWEB,
        "mvc.command.name=/exportMisReportResourceURL"
    },
    service = MVCResourceCommand.class
)
public class ExportMisReportResourceCommand implements MVCResourceCommand {

    private static final Log log = LogFactoryUtil.getLog(ExportMisReportResourceCommand.class);

    @Override
    public boolean serveResource(ResourceRequest resourceRequest, ResourceResponse resourceResponse)
            throws PortletException {
        try {
            log.info("Starting Excel export...");

            // Fetch the data
			/*
			 * List<documentstore> results = fetchDocumentData(resourceRequest);
			 * 
			 * if (results == null || results.isEmpty()) {
			 * writeNoDataResponse(resourceResponse); return false; }
			 */
            List<documentstore> dummyData = new ArrayList<>();
            documentstore doc = new documentstore();
            doc.setSolId("12345");
            doc.setSectionName("Finance");
            doc.setDocumentType("Report");
            //doc.setValidityFrom(new Date());
            //doc.setValidityTo(new Date());
            dummyData.add(doc);
            // Set response headers for Excel
            resourceResponse.setContentType("application/vnd.ms-excel");
            resourceResponse.addProperty("Content-Disposition", "attachment; filename=CurrentDocumentReport.xls");

            // Write Excel file to response output stream
            try (OutputStream os = resourceResponse.getPortletOutputStream()) {
                generateExcelWorkbook(dummyData, os);
            }

        } catch (Exception e) {
            log.error("Error generating Excel report", e);
            throw new PortletException(e);
        }
        return true;
    }

    private List<documentstore> fetchDocumentData(ResourceRequest resourceRequest) {
        ThemeDisplay themeDisplay = (ThemeDisplay) resourceRequest.getAttribute(WebKeys.THEME_DISPLAY);
        return (List<documentstore>) themeDisplay.getRequest().getSession().getAttribute("results1");
    }

    private void writeNoDataResponse(ResourceResponse resourceResponse) throws Exception {
        resourceResponse.getWriter().write("No data available to export.");
        log.info("No data found to export.");
    }

    private void generateExcelWorkbook(List<documentstore> results, OutputStream os) throws Exception {
        WritableWorkbook workbook = Workbook.createWorkbook(os);
        WritableSheet sheet = workbook.createSheet("Current Report", 0);

        // Write headers
        writeHeaders(sheet);

        // Write data rows
        writeDataRows(sheet, results);

        workbook.write();
        workbook.close();
    }

    private void writeHeaders(WritableSheet sheet) throws Exception {
        String[] headers = {
            "SOL ID", "SECTION NAME", "DOCUMENT TYPE", "PARTICULAR", "VALIDITY FROM", "VALIDITY TO", "SR NUMBER",
            "ACC NUMBER", "DOCUMENT SERIAL NO.", "DATE OF ENTRY", "CREATED BY (Name and Emp ID)",
            "CURRENT CUSTODIAN (Name and Emp ID)", "DOCUMENT STATUS", "NEW DOCUMENT STATUS",
            "RECORD UPDATED ON", "RECORD UPDATED BY (Name and Emp ID)", "INCIDENT DETAILS",
            "REASON FOR DELETION", "ARCHIVAL DATE", "ARCHIVAL REASON", "ARCHIVAL METHOD"
        };

        for (int i = 0; i < headers.length; i++) {
            sheet.addCell(new Label(i, 0, headers[i]));
        }
    }

    private void writeDataRows(WritableSheet sheet, List<documentstore> results) throws Exception {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");

        for (int i = 0; i < results.size(); i++) {
            documentstore doc = results.get(i);

            // Create rows and write data using `Label`
            sheet.addCell(new Label(0, i + 1, doc.getSolId()));
            sheet.addCell(new Label(1, i + 1, doc.getSectionName()));
            sheet.addCell(new Label(2, i + 1, doc.getDocumentType()));
            //sheet.addCell(new Label(3, i + 1, doc.getValidityFrom() != null ? dateFormat.format(doc.getValidityFrom()) : ""));
            //sheet.addCell(new Label(4, i + 1, doc.getValidityTo() != null ? dateFormat.format(doc.getValidityTo()) : ""));
        }
    
    }

    private String formatNullableDate(Date date, SimpleDateFormat dateFormat) {
        return date != null ? dateFormat.format(date) : "";
    }
}
