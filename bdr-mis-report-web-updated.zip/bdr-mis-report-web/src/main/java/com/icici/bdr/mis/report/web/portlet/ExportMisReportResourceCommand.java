package com.icici.bdr.mis.report.web.portlet;

import com.icici.bdr.mis.report.web.constants.BdrMisReportWebPortletKeys;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCResourceCommand;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.util.WebKeys;
import com.student.model.Student;

import java.util.List;

import javax.portlet.PortletException;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;
import javax.servlet.http.HttpSession;

import org.osgi.service.component.annotations.Component;

@Component(
	    property = {
	    	"javax.portlet.name="+BdrMisReportWebPortletKeys.BDRMISREPORTWEB,
	        "mvc.command.name=/exportMisReportResourceURL"
	    },
	    service = MVCResourceCommand.class
	)
public class ExportMisReportResourceCommand implements MVCResourceCommand {

	
	final Log log=LogFactoryUtil.getLog(this.getClass());

	@Override
	public boolean serveResource(ResourceRequest resourceRequest, ResourceResponse resourceResponse) throws PortletException {

		log.info("kkkk::::");
		////latest
		final long serialVersionUID = 4493918011117442420L;

	    final String COMMA = ",";
		log.info("::::::::::::inside export MIS report current doc :::::::::::::::");
		ThemeDisplay themeDisplay = (ThemeDisplay) resourceRequest.getAttribute(WebKeys.THEME_DISPLAY);

		HttpSession sessionUserPost = themeDisplay.getRequest().getSession();

		List<Student> studentList = (List<Student>) sessionUserPost.getAttribute("results1");
		 for (Student student : studentList) {
			 
			 System.out.println("student.getStudentName()::::::"+student.getStudentName());
			 
		 }
		//  try {
           
            /*
            HttpSession httpSession = PortalUtil.getHttpServletRequest(resourceRequest).getSession();
            List<documentstore> results = (List<documentstore>) httpSession.getAttribute("results1");

            
            //List<documentstore> results = (List<documentstore>) resourceRequest.getPortletSession().getAttribute("results1",PortletSession.APPLICATION_SCOPE);
            
           

            if (results == null || results.isEmpty()) {
                resourceResponse.getWriter().write("No data available to export.");
                log.info("::::::::MIS REPORT RESULTS  are :::::::::::::::::"+results);
                return false;
            }

           
            resourceResponse.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            resourceResponse.addProperty("Content-Disposition", "attachment; filename=CurrentDocumentReportByAdmin.xls");

         
            WritableWorkbook workbook = Workbook.createWorkbook(resourceResponse.getPortletOutputStream());
            WritableSheet sheet = workbook.createSheet("Current Report", 0);

            // Write headers
            String[] headers = {
                "SOL ID", "SECTION NAME", "DOCUMENT TYPE", "PARTICULAR", "VALIDITY FROM", "VALIDITY TO", "SR NUMBER",
                "ACC NUMBER", "DOCUMENT SERIAL NO.", "DATE OF ENTRY", "CREATED BY (Name and Emp ID)",
                "CURRENT CUSTODIAN (Name and Emp ID)", "DOCUMENT STATUS", "NEW DOCUMENT STATUS",
                "RECORD UPDATED ON", "RECORD UPDATED BY (Name and Emp ID)", "INCIDENT DETAILS",
                "REASON FOR DELETION", "ARCHIVAL DATE", "ARCHIVAL REASON", "ARCHIVAL METHOD"
            };

            for (int i = 0; i < headers.length; i++) {
                sheet.addCell(new Label(i, 0, headers[i]));
            }

            // Write data rows
            SimpleDateFormat ddmmyyyyFormat = new SimpleDateFormat("dd-MM-yyyy");
            for (int i = 0; i < results.size(); i++) {
                documentstore upload = documentstoreLocalServiceUtil.getdocumentstore(results.get(i).getDocumentId());

                String validFrom = upload.getValidityFrom() != null ? ddmmyyyyFormat.format(upload.getValidityFrom()) : "";
                String validTo = upload.getValidityTo() != null ? ddmmyyyyFormat.format(upload.getValidityTo()) : "";
                String createdDate = upload.getCreatedDate() != null ? ddmmyyyyFormat.format(upload.getCreatedDate()) : "";
                String modifiedDate = upload.getModifiedDate() != null ? ddmmyyyyFormat.format(upload.getModifiedDate()) : "";

                sheet.addCell(new Label(0, i + 1, upload.getSolId()));
                sheet.addCell(new Label(1, i + 1, upload.getSectionName()));
                sheet.addCell(new Label(2, i + 1, upload.getDocumentType()));
                sheet.addCell(new Label(3, i + 1, upload.getPerticular()));
                sheet.addCell(new Label(4, i + 1, validFrom));
                sheet.addCell(new Label(5, i + 1, validTo));
                sheet.addCell(new Label(6, i + 1, upload.getSrNumber()));
                sheet.addCell(new Label(7, i + 1, upload.getAccNumber()));
                sheet.addCell(new Label(8, i + 1, upload.getDocumentSN()));
                sheet.addCell(new Label(9, i + 1, createdDate));
                sheet.addCell(new Label(10, i + 1, upload.getCreatedBy()));
                sheet.addCell(new Label(11, i + 1, upload.getCurrentCustNm() + ", " + upload.getCurrentCustodian()));
                sheet.addCell(new Label(12, i + 1, upload.getStatus()));
                sheet.addCell(new Label(13, i + 1, upload.getSelDocOpt()));
                sheet.addCell(new Label(14, i + 1, modifiedDate));
                sheet.addCell(new Label(15, i + 1, upload.getModifiedBy()));
                sheet.addCell(new Label(16, i + 1, upload.getIncidentBox()));
                sheet.addCell(new Label(17, i + 1, upload.getDeletedReason()));
                sheet.addCell(new Label(18, i + 1, modifiedDate));
                sheet.addCell(new Label(19, i + 1, upload.getArchivalReason()));
                sheet.addCell(new Label(20, i + 1, upload.getArchivalMethod()));
            }

            sheet.getSettings().setProtected(true);
            workbook.write();
            workbook.close();

        } catch (Exception e) {
            throw new PortletException("Error generating Excel report", e);
        }
        */

        return true;
   }
}
