package com.icici.bdr.mis.report.web.portlet;

import com.icici.bdr.mis.report.web.constants.BdrMisReportWebPortletKeys;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCResourceCommand;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.kernel.util.WebKeys;

import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.portlet.PortletException;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;
import javax.servlet.http.HttpSession;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.osgi.service.component.annotations.Component;

@Component(property = { "javax.portlet.name=" + BdrMisReportWebPortletKeys.BDRMISREPORTWEB,
		"mvc.command.name=/exportMisReportResourceURL" }, service = MVCResourceCommand.class)
public class ExportMisReportResourceCommand implements MVCResourceCommand {

	final Log log = LogFactoryUtil.getLog(this.getClass());

	public boolean serveResource(ResourceRequest resourceRequest, ResourceResponse resourceResponse)
			throws PortletException {
		
		try {
			/*
			 * List<documentstore> results = fetchDocumentData(resourceRequest); if (results
			 * == null || results.isEmpty()) { writeNoDataResponse(resourceResponse); return
			 * false; }
			 */
			System.out.println("Testing:::::::::::");
			List<documentstore> dummyData = new ArrayList<>();
			documentstore doc = new documentstore();
			doc.setSolId("12345");
			doc.setSectionName("Finance");
			doc.setDocumentType("Report");
			//doc.setValidityFrom(new Date());
			//doc.setValidityTo(new Date());
			dummyData.add(doc);
			Workbook workbook = createWorkbook(dummyData);
			writeExcelToResponse(resourceResponse, workbook);
			System.out.println("done::::::::::");
		} catch (Exception e) {
			log.error("Error generating Excel report", e);
			throw new PortletException(e);
		}

		return true;
	}

	private void writeNoDataResponse(ResourceResponse resourceResponse) throws Exception {
		resourceResponse.getWriter().write("No data available to export.");
	}

	private CellStyle createHeaderStyle(Workbook workbook) {
		CellStyle style = workbook.createCellStyle();
		Font font = workbook.createFont();
		font.setBold(true);
		style.setFont(font);
		return style;
	}

	private void writeExcelToResponse(ResourceResponse resourceResponse, Workbook workbook) throws Exception {
		resourceResponse.setContentType("application/octet-stream");
		resourceResponse.addProperty("Content-Disposition", "attachment; filename=CurrentDocumentReport.xlsx");

		try (OutputStream out = resourceResponse.getPortletOutputStream()) {
		    workbook.write(out);
		    out.flush(); // Ensure everything is written before closing
		}
	}

	private void writeDataRows(Sheet sheet, List<documentstore> results) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		for (int i = 0; i < results.size(); i++) {
			documentstore doc = results.get(i);
			Row row = sheet.createRow(i + 1);

			row.createCell(0).setCellValue(doc.getSolId());
			row.createCell(1).setCellValue(doc.getSectionName());
			row.createCell(2).setCellValue(doc.getDocumentType());
			// row.createCell(3).setCellValue(doc.getValidityFrom() != null ?
			// dateFormat.format(doc.getValidityFrom()) : "");
			// row.createCell(4).setCellValue(doc.getValidityTo() != null ?
			// dateFormat.format(doc.getValidityTo()) : "");
		}
	}

	private void writeHeaders(Sheet sheet, String[] headers, Workbook workbook) {
		Row headerRow = sheet.createRow(0);
		CellStyle headerStyle = createHeaderStyle(workbook);
		for (int i = 0; i < headers.length; i++) {
			Cell cell = headerRow.createCell(i);
			cell.setCellValue(headers[i]);
			cell.setCellStyle(headerStyle);
		}
	}

	private Workbook createWorkbook(List<documentstore> results) {
		Workbook workbook = new XSSFWorkbook();
		Sheet sheet = workbook.createSheet("Current Report");

		// Write headers
		String[] headers = { "SOL ID", "SECTION NAME", "DOCUMENT TYPE", "VALIDITY FROM", "VALIDITY TO" };
		writeHeaders(sheet, headers, workbook);

		// Write data rows
		writeDataRows(sheet, results);

		return workbook;
	}

	private List<documentstore> fetchDocumentData(ResourceRequest resourceRequest) {
		ThemeDisplay themeDisplay = (ThemeDisplay) resourceRequest.getAttribute(WebKeys.THEME_DISPLAY);
		HttpSession session = PortalUtil.getHttpServletRequest(resourceRequest).getSession();

		@SuppressWarnings("unchecked")
		List<documentstore> results = (List<documentstore>) session.getAttribute("results1");
		return results;
	}
}
