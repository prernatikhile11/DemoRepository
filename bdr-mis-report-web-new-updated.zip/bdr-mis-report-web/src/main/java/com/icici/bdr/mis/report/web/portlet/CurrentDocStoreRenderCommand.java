package com.icici.bdr.mis.report.web.portlet;

import com.icici.bdr.mis.report.web.constants.BdrMisReportWebPortletKeys;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCRenderCommand;

import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.osgi.service.component.annotations.Component;

@Component(
	    immediate = true,
	    property = {
	    		"javax.portlet.name=" + BdrMisReportWebPortletKeys.BDRMISREPORTWEB,
	       "mvc.command.name=/currentDocStoreRenderUrl"
	    },
	    service = MVCRenderCommand.class
	)
public class CurrentDocStoreRenderCommand implements MVCRenderCommand{

	@Override
	public String render(RenderRequest renderRequest, RenderResponse renderResponse) throws PortletException {
		System.out.println("CurrentDocStoreRenderCommand  invoked::::::::::::::::::");
		
		return "/currentDocumentReports.jsp";
	}

}
