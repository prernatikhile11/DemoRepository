package com.icici.bdr.mis.report.web.constants;

/**
 * @author Mahammad.Saleem
 */
public class BdrMisReportWebPortletKeys {

	public static final String BDRMISREPORTWEB =
		"com_icici_bdr_mis_report_web_BdrMisReportWebPortlet";

}