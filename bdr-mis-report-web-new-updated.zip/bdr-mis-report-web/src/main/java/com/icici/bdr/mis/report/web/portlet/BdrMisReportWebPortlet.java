package com.icici.bdr.mis.report.web.portlet;

import com.icici.bdr.mis.report.web.constants.BdrMisReportWebPortletKeys;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCPortlet;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.util.HtmlUtil;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.WebKeys;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.Portlet;
import javax.portlet.PortletException;
import javax.portlet.PortletSession;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.osgi.service.component.annotations.Component;

/**
 * @author Mahammad.Saleem
 */
@Component(immediate = true, property = { "com.liferay.portlet.display-category=category.sample",
		"com.liferay.portlet.header-portlet-css=/css/main.css", "com.liferay.portlet.instanceable=true",
		"javax.portlet.display-name=BdrMisReportWeb", "javax.portlet.init-param.template-path=/",
		"javax.portlet.init-param.view-template=/view.jsp",
		"javax.portlet.name=" + BdrMisReportWebPortletKeys.BDRMISREPORTWEB,
		"javax.portlet.resource-bundle=content.Language", "javax.portlet.security-role-ref=power-user,user",
		"javax.portlet.version=3.0" }, service = Portlet.class)
public class BdrMisReportWebPortlet extends MVCPortlet {

	private static final long serialVersionUID = 4493918011117442420L;
	public static final String COMMA = ",";

	final Log _log = LogFactoryUtil.getLog(this.getClass());

	/*
	 * @Override public void render(RenderRequest request, RenderResponse response)
	 * throws IOException, PortletException {
	 * _log.info("::::::inside render:::::::::::::::**");
	 * 
	 * String getParam = request.getParameter("mvcPath");
	 * _log.info("::::::::::::getparam:::::::***" + getParam); String solId =
	 * HtmlUtil.escape(ParamUtil.getString(request, "solId"));
	 * 
	 * PortletSession session = request.getPortletSession();
	 * _log.info(":::::::session reslurs::::::::::::" +
	 * session.getAttribute("results"));
	 * 
	 * // session.setAttribute("results", results, PortletSession.PORTLET_SCOPE);
	 * session.setAttribute("results1", session.getAttribute("results"),
	 * PortletSession.APPLICATION_SCOPE);
	 * 
	 * if (getParam != null &&
	 * getParam.equalsIgnoreCase("/currentDocumentReports.jsp")) {
	 * _log.info("...inside :::::::::::"); request.setAttribute("results",
	 * session.getAttribute("results")); request.se
	 * include("/currentDocumentReports.jsp", request, response);
	 * 
	 * 
	 * }
	 * 
	 * // for edit
	 * 
	 * else if (getParam != null &&
	 * getParam.equalsIgnoreCase("/expiredDocReportsByAdmin.jsp")) {
	 * _log.info("...inside :::::::::::"); include("/expiredDocReportsByAdmin.jsp",
	 * request, response); }
	 * 
	 * else if (getParam != null &&
	 * getParam.equalsIgnoreCase("/handTakeoverReportsByAdmin.jsp")) {
	 * _log.info("...inside :::::::::::");
	 * include("/handTakeoverReportsByAdmin.jsp", request, response); }
	 * 
	 * else if (getParam != null &&
	 * getParam.equalsIgnoreCase("/monthlyReportsByAdmin.jsp")) {
	 * _log.info("...inside redirect to view all jsp after submit:::::::::::");
	 * include("/monthlyReportsByAdmin.jsp", request, response); }
	 * 
	 * else { super.doView(request, response);
	 * 
	 * }
	 * 
	 * }
	 */
	
	
	@Override
	public void doView(RenderRequest renderRequest, RenderResponse renderResponse)
			throws IOException, PortletException {
		
		super.doView(renderRequest, renderResponse);
	}

	public Date convertStringToDate(String dateString) {
		Date date = null;
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		// ("dd-MM-yyyy");
		try {
			date = formatter.parse(dateString);
			_log.info("---formatted date--" + date);

		} catch (Exception ex) {
			_log.info(ex);
		}
		return date;
	}

	public void displayReportsAction(ActionRequest request, ActionResponse response)
			throws IOException, PortletException {
		PortletSession session = request.getPortletSession();
		String solId = ParamUtil.getString(request, "solId");
		Date fromDate = convertStringToDate(ParamUtil.getString(request, "fromDate"));
		Date toDate = convertStringToDate(ParamUtil.getString(request, "toDate"));
		String reportsName = HtmlUtil.escape(ParamUtil.getString(request, "reportsName"));
		ThemeDisplay themeDisplay = (ThemeDisplay) request.getAttribute(WebKeys.THEME_DISPLAY);
		_log.info("::::::::--solId-:::"+solId + "----fromDate-----" + fromDate + "--toDate---" + toDate + "---reportsName--" + reportsName);

		List<documentstore> results = new ArrayList<>();
		//List<expireddocstore> results1 = new ArrayList<>();
		//List<handtakeoverrpt> results2 = new ArrayList<>();
		//List<monthlyreports> results3 = new ArrayList<>();
		String renderPageNm = "";
		try {
			if (solId != null && !solId.trim().isEmpty()) {

				if (reportsName.equalsIgnoreCase("CurrentDocumentReports")) {
					_log.info("--SOLID Available-----");
					//DynamicQuery searchQuery = documentstoreLocalServiceUtil.dynamicQuery();
					//searchQuery.add(RestrictionsFactoryUtil.between("createdDate", fromDate, toDate));
					//searchQuery.add(RestrictionsFactoryUtil.eq("solId", solId));
					//results = documentstoreLocalServiceUtil.dynamicQuery(searchQuery);
					request.setAttribute("results", results);
					_log.info(":::::::::::::results.size:::::::::::: " + results.size());
					session.setAttribute("results", results, PortletSession.PORTLET_SCOPE);
					//renderPageNm = "/currentDocumentReports.jsp";
					response.setRenderParameter("mvcRenderCommandName", "/currentDocStoreRenderUrl");
					return;
				} else if (reportsName.equalsIgnoreCase("ExpiredDocumentReports")) {
					//DynamicQuery searchQuery = expireddocstoreLocalServiceUtil.dynamicQuery();
					//searchQuery.add(RestrictionsFactoryUtil.between("createdDate", fromDate, toDate));
					//searchQuery.add(RestrictionsFactoryUtil.eq("solId", solId));
					//results1 = expireddocstoreLocalServiceUtil.dynamicQuery(searchQuery);
					request.setAttribute("results", results);
					session.setAttribute("results", results, PortletSession.PORTLET_SCOPE);
					response.setRenderParameter("mvcRenderCommandName", "/expiredDocRenderUrl");
					//renderPageNm = "/expiredDocReportsByAdmin.jsp";
				} else if (reportsName.equalsIgnoreCase("HandOverTakeOverReports")) {
					//DynamicQuery searchQuery = handtakeoverrptLocalServiceUtil.dynamicQuery();
					//searchQuery.add(RestrictionsFactoryUtil.between("createdDate", fromDate, toDate));
					//searchQuery.add(RestrictionsFactoryUtil.eq("solId", solId));
					//results2 = handtakeoverrptLocalServiceUtil.dynamicQuery(searchQuery);
					request.setAttribute("results", results);
					session.setAttribute("results", results, PortletSession.PORTLET_SCOPE);
					renderPageNm = "/handTakeoverReportsByAdmin.jsp";
				} else if (reportsName.equalsIgnoreCase("MonthlyVerificationReports")) {
					//DynamicQuery searchQuery = monthlyreportsLocalServiceUtil.dynamicQuery();
					//searchQuery.add(RestrictionsFactoryUtil.between("createdDate", fromDate, toDate));
					//searchQuery.add(RestrictionsFactoryUtil.eq("solId", solId));
					//results3 = monthlyreportsLocalServiceUtil.dynamicQuery(searchQuery);
					request.setAttribute("results", results);
					session.setAttribute("results", results, PortletSession.PORTLET_SCOPE);
					renderPageNm = "/monthlyReportsByAdmin.jsp";
				}

			} else {
				if (reportsName.equalsIgnoreCase("CurrentDocumentReports")) {
					_log.info("--SOLID NULL-----");
					//DynamicQuery searchQuery = documentstoreLocalServiceUtil.dynamicQuery();
					//searchQuery.add(RestrictionsFactoryUtil.between("createdDate", fromDate, toDate));
					//results = documentstoreLocalServiceUtil.dynamicQuery(searchQuery);
					_log.info("results size ==== " + results.size());
					request.setAttribute("results", results);
					//renderPageNm = "/currentDocumentReports.jsp";
					session.setAttribute("results", results, PortletSession.PORTLET_SCOPE);

				} else if (reportsName.equalsIgnoreCase("HandOverTakeOverReports")) {
					//DynamicQuery searchQuery = handtakeoverrptLocalServiceUtil.dynamicQuery();
					//searchQuery.add(RestrictionsFactoryUtil.between("createdDate", fromDate, toDate));
					//results2 = handtakeoverrptLocalServiceUtil.dynamicQuery(searchQuery);
					request.setAttribute("results", results);
					renderPageNm = "/handTakeoverReportsByAdmin.jsp";
					session.setAttribute("results", results, PortletSession.PORTLET_SCOPE);

				} else if (reportsName.equalsIgnoreCase("ExpiredDocumentReports")) {
					//DynamicQuery searchQuery = expireddocstoreLocalServiceUtil.dynamicQuery();
					//searchQuery.add(RestrictionsFactoryUtil.between("createdDate", fromDate, toDate));
					//results1 = expireddocstoreLocalServiceUtil.dynamicQuery(searchQuery);
					request.setAttribute("results", results);
//					renderPageNm = "/expiredDocReportsByAdmin.jsp";
	
					session.setAttribute("results", results, PortletSession.PORTLET_SCOPE);
					response.setRenderParameter("mvcRenderCommandName", "/expiredDocRenderUrl");

				} else if (reportsName.equalsIgnoreCase("MonthlyVerificationReports")) {
					//DynamicQuery searchQuery = monthlyreportsLocalServiceUtil.dynamicQuery();
					//searchQuery.add(RestrictionsFactoryUtil.between("createdDate", fromDate, toDate));
					//results3 = monthlyreportsLocalServiceUtil.dynamicQuery(searchQuery);
					request.setAttribute("results", results);
					renderPageNm = "/monthlyReportsByAdmin.jsp";
					session.setAttribute("results", results, PortletSession.PORTLET_SCOPE);
				}

			} // outer else closed....
		} catch (SystemException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

		request.setAttribute("solId", solId);
		request.setAttribute("reportsName", reportsName);
		request.setAttribute("fromDate", ParamUtil.getString(request, "fromDate"));
		request.setAttribute("toDate", ParamUtil.getString(request, "toDate"));

		//response.setRenderParameter("mvcPath", renderPageNm);

	}

	/*
	 * public void serveResource(ResourceRequest resourceRequest, ResourceResponse
	 * resourceResponse) throws IOException, PortletException {
	 * 
	 * String action = ParamUtil.getString(resourceRequest, "action");
	 * _log.info("action-----" + action);
	 * 
	 * if (action.equalsIgnoreCase("download")) {
	 * 
	 * String fileName = ParamUtil.getString(resourceRequest, "fileName"); String
	 * path = System.getProperty("catalina.base"); String fileLocation =
	 * GetterUtil.getString(PropsUtil.get("file.location"));
	 * _log.info("fileLocation " + fileLocation); File fileDestLocation =
	 * new File(path + "\\webapps\\" + fileLocation);
	 * _log.info("fileDestLocation " + fileDestLocation); File destFile =
	 * new File(fileDestLocation + "/" + fileName);
	 * 
	 * _log.info( "filePath server resource fileDestLocation---" +
	 * fileDestLocation + "---filePath-----" + destFile);
	 * resourceResponse.setContentType("application/pdf");
	 * resourceResponse.setProperty("Content-Disposition", "attachment;filename=" +
	 * fileName);
	 * 
	 * OutputStream out = resourceResponse.getPortletOutputStream();
	 * 
	 * byte[] fileByte = new byte[(int) destFile.length()]; FileInputStream
	 * fileInputStream = new FileInputStream(destFile);
	 * fileInputStream.read(fileByte); out.write(fileByte);
	 * 
	 * PortletResponseUtil.sendFile(resourceRequest, resourceResponse, fileName,
	 * fileInputStream, "multipart/related");
	 * 
	 * out.flush(); out.close(); super.serveResource(resourceRequest,
	 * resourceResponse); }
	 * 
	 * }
	 */
}